%% Load Deep Learning Toolbox
%% addpath('C:\Users\dell\Desktop\Deep_Learning');

%% Load data
%% Including Lat, Lon, NDVI, LST, Albedo, DEM, SM_SMAP
%% Note: The input data of NC-DBN needs to be padding operation
%% Load model (DBN, NC-DBN)

for para=1:number 

    %% Test input data curation
    Lat_low = reshape(Y,[],1);
    Lon_low = reshape(X,[],1);
    NDVI_low = double(reshape(ND{ceil(para/16.0)},[],1));
    LST_low = double(reshape(L{ceil(para/8.0)+1},[],1));
    Aldebo_low = double(reshape(A{para},[],1)); 
    DEM_low=double(reshape(DEM_C,[],1));
    SM_SMAP2 = double(reshape(SC{para},[],1));

    %% data curation
    data_low_predict={Lon_low,Lat_low,DEM_low,Aldebo_low,LST_low,NDVI_low,SM_SMAP2};                   %Dataset matrix after adding DEM
    group2 = cell2mat(data_low_predict);
    [m,n]=find(isnan(group2)); 
    group2(:, end)=[];
    group2 = group2';
    [~, cols] = find( isnan(group2) );
    input2 = group2(1:end, :);
    xmin_low = min(input2,[],2);
    xmax_low = max(input2,[],2);
    input_predict = myMapminmax(input2, xmin_low, xmax_low, 0, 1);
    input_predict(:, cols) = [];

    %% DBN testing
    dataset_est=sim(net,input_predict); %Perform simulation operations
    % % dataset_est = SimSplit(6,input_predict,net);%Perform simulation operations
    % % dataset_est=mapminmax('reverse',dataset_est,y_norm_param);%Inverse normalization, not used here
    dataset_est=dataset_est';

end