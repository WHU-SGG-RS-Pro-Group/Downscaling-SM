import os, datetime, time
import warnings
import argparse
from model.model import RDN
from dataset import *
import numpy as np
import glob
import scipy.io as scio
import re
import h5py
import gdal

warnings.filterwarnings("ignore")

parser = argparse.ArgumentParser(description='PDN')
parser.add_argument('--model', default='RDN_v1', type=str, help='choose path of model')
parser.add_argument('--nDense', type=int, default=6, help='nDenselayer of RDB')
parser.add_argument('--growthRate', type=int, default=32, help='growthRate of dense net')
parser.add_argument('--nFeat', type=int, default=64,  help='number of feature maps')
parser.add_argument('--batch_size', default=64, type=int, help='batch size')
parser.add_argument('--epoch', default=100, type=int, help='number of train epoch')
parser.add_argument('--lr', default=1e-4, type=float, help='initial learning rate for Adam')
parser.add_argument('--gpu', default='3', type=str, help='gpu id')
parser.add_argument('--test_data_dir', default='E:/zhf/Machine_Learning/RF2/zhf_ResNet_TEST/test_low_data/', type=str, help='path of hr image')
parser.add_argument('--result_dir', default='E:/zhf/Machine_Learning/RF2/zhf_ResNet_TEST/python_results/low/', type=str, help='path of hr image')
parser.add_argument('--ncha_aux_data', type=int, default=6, help='number of auxiliary data channels to use')
parser.add_argument('--ncha_data', type=int, default=1, help='number of precipitation data channels to use')

args = parser.parse_args()

cuda = torch.cuda.is_available()
os.environ["CUDA_VISIBLE_DEVICES"] = '0,1'
savedir = os.path.join('models', args.model)

if not os.path.exists(savedir):
    os.mkdir(savedir)


def data_loader(matpath):
    mat = h5py.File(matpath, 'r+')
    mat_in = np.transpose(mat[list(mat.keys())[0]])
    mat_in = np.array(mat_in).astype(np.float32)
    [num, cha, hei, wid] = mat_in.shape
    mat_in = torch.from_numpy(mat_in).contiguous().view(num, cha, hei, wid)
    mat_out = mat_in.float().cuda()
    return mat_out


def find_checkpoint(savedir):
    file_list = glob.glob(os.path.join(savedir, 'model_*.pth'))
    if file_list:
        epochs_exist = []
        for m in file_list:
            result = re.findall(".*model_(.*).pth.*", m)
            epochs_exist.append(int(result[0]))
        initial_epoch = max(epochs_exist)
    else :
        initial_epoch = 0
    return initial_epoch


def pymat2mat(mat_py):
    [cha, hei, wid] = mat_py.shape
    mat = np.zeros((hei, wid, cha), dtype=np.float)
    for i in range(hei):
        for j in range(wid):
            mat[i, j, :] = mat_py[:, i, j]
    return mat


def mat_reshape(mat_in, hei_out, wid_out):
    [num, cha, hei, wid] = mat_in.shape
    mat_out = np.zeros((hei_out, wid_out, cha), dtype=np.float)
    for i in range(int(wid_out/wid)):
        for j in range(int(hei_out/hei)):
            mat_out[j*hei:(j+1)*hei, i*wid:(i+1)*wid, :] = pymat2mat(mat_in[j*int(wid_out/wid)+i, :, :, :].reshape(cha, hei, wid))
    return mat_out



def main():
    # load model
    model = RDN(args)
    initial_epoch = find_checkpoint(savedir=savedir)
    if initial_epoch > 0:
        print('==> Resuming by loading epoch %03d' % initial_epoch)
        model = torch.load(os.path.join(savedir, 'model_%03d.pth' % initial_epoch))
    model.eval()
    if cuda:
        model = model.cuda()

    # load test data
    # min_max = (0, 1)
    for m in range(number):
        # test_data_path = os.path.join(args.test_data_dir, 'auxiliary_data.mat')
        # test_data = data_loader(test_data_path)
        # savepath = os.path.join(args.result_dir, 'rdn_v1.mat')
        files = os.listdir(args.test_data_dir)  # zhf
        test_data_path = os.path.join(args.test_data_dir, files[m])
        test_data = data_loader(test_data_path)
        savepath = os.path.join(args.result_dir, 'rdn_test_low'+ str(m+1).zfill(3)+'.mat')

        [num_test_data, cha_test_data, hei_test_data, wid_test_data] = test_data.shape
        pdn_result = np.zeros((num_test_data, 1, hei_test_data, wid_test_data), dtype=np.float32)

        start_time = time.time()
        for n in range(num_test_data):
            sub_data = test_data[n, :, :, :]
            sub_data = sub_data.float().view(1, cha_test_data, hei_test_data, wid_test_data)
            sub_data = sub_data.cuda()
            sub_out = model(sub_data)
            sub_out = sub_out.cpu()  # .clamp_(*min_max)
            sub_out = sub_out.detach().numpy().astype(np.float32)
            pdn_result[n, :, :, :] = sub_out
        elapsed_time = time.time() - start_time
        print('time is %4.4f s' % elapsed_time)

        pdn_result_np = np.zeros((num_test_data, 1, hei_test_data - 20, wid_test_data - 20), dtype=np.float32)
        pdn_result_np = pdn_result[:, :, 10: hei_test_data - 10, 10: wid_test_data - 10]
        pdn_result_mat = mat_reshape(pdn_result_np, 38, 98)
        scio.savemat(savepath, {'pdn_result': pdn_result_mat})


if __name__ == '__main__':
    main()
